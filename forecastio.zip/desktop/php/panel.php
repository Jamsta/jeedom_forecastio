<?php
if (!isConnect()) {
	throw new Exception('{{401 - Accès non autorisé}}');
}

?>
    <div id="fields">
      <div class="inner">
        <span class="temperature" data-field="temperature">Temperature</span>
        <span class="precipIntensity" data-field="precipIntensity">Precipitation</span>
        <span class="windSpeed" data-field="windSpeed">Wind</span>
        <span class="humidity" data-field="humidity">Humidity</span>
        <span class="pressure" data-field="pressure">Pressure</span>
        <div class="indicator"></div>
      </div>
    </div>

    <div id="loading">
      LOADING…
    </div>

    <div id="content">
      <div class="top">

        <div class="current">
          <div class="inner">
            <canvas id="current_icon" width="110" height="110" style="width:110px; height:110px"></canvas>
            <div class="temp"></div>
            <div class="conditions"></div>
          </div>
        </div>

        <div class="hour">
          <div class="summary"></div>
          <div id="hour_chart"></div>
        </div>

      </div>

      <div class="day">
        <div class="summary"></div>
        <div id="day_chart"></div>
      </div>

      <div class="week">
        <div class="summary"></div>
        <div id="week_chart"></div>
      </div>
    </div>

<script src="http://forecast.io/lines/lines.min.js"></script>
